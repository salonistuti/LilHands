// https://images.unsplash.com/photo-1537301636683-5ac98e0466a2?crop=entropy&cs=tinysrgb&fm=jpg&ixid=MnwzMjM4NDZ8MHwxfHJhbmRvbXx8fHx8fHx8fDE2NjEwNjUwNzM&ixlib=rb-1.2.1&q=80

// F7FD04
// FBDF07
// #FFEA11
// ./images/stephan-bechert-yFV39g6AZ5o-unsplash.jpg


function changebg()
{
    const img =[
        'url("p1.jpg")',
        'url("p2.jpg")',
        'url("p3.png")',
    ]
    const Section = document.querySelector('.banner');
    //console.log(Section);
    const b=img[Math.floor(Math.random()*img.length)];
    Section.style.backgroundImage=b;
}
 setInterval(changebg,2000);