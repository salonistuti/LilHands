var firebaseConfig = {
    apiKey: "AIzaSyAGE7Y6x4jN1zEelkP7W0qetZqv_SiMZac",
    authDomain: "lilhands-ca422.firebaseapp.com",
    projectId: "lilhands-ca422",
    storageBucket: "lilhands-ca422.appspot.com",
    messagingSenderId: "794622307653",
    appId: "1:794622307653:web:c6df9af0eb888b4bd6222c",
    measurementId: "G-SF0JPYL2WX"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
