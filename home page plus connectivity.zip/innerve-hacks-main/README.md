# Pure HTML+CSS Website Home Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/atiakhan/pen/oNqmRzd](https://codepen.io/atiakhan/pen/oNqmRzd).

Pure HTML+CSS based website home page